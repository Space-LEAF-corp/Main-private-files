#!/usr/bin/env bash
# enable_auto_merge_graphql.sh
#
# Enables auto-merge for a PR via GitHub GraphQL API.
# Usage:
#   export GITHUB_TOKEN="ghp_XXXXXXXXXXXX"
#   ./enable_auto_merge_graphql.sh <PR_NUMBER> <OWNER> <REPO> [MERGE_METHOD]
#
# Example:
#   ./enable_auto_merge_graphql.sh 123 Space-LEAF-Corp platform SQUASH
#
# MERGE_METHOD: SQUASH (default) | REBASE | MERGE
#
set -euo pipefail

if ! command -v curl >/dev/null 2>&1; then
  echo "ERROR: curl is required"
  exit 1
fi
if ! command -v jq >/dev/null 2>&1; then
  echo "ERROR: jq is required"
  exit 1
fi

if [[ -z "${GITHUB_TOKEN:-}" ]]; then
  echo "ERROR: GITHUB_TOKEN environment variable not set."
  echo "Export it: export GITHUB_TOKEN='ghp_...'"
  exit 1
fi

PR_NUMBER="${1:-}"
OWNER="${2:-}"
REPO="${3:-}"
MERGE_METHOD="${4:-SQUASH}" # SQUASH | REBASE | MERGE

if [[ -z "$PR_NUMBER" || -z "$OWNER" || -z "$REPO" ]]; then
  cat <<EOF
Usage: $0 <PR_NUMBER> <OWNER> <REPO> [MERGE_METHOD]
Example: $0 123 Space-LEAF-Corp platform SQUASH
EOF
  exit 1
fi

GH_API_GRAPHQL="https://api.github.com/graphql"
AUTH_HEADER="Authorization: Bearer ${GITHUB_TOKEN}"
CONTENT_HEADER="Content-Type: application/json"

echo "Fetching PR node id for ${OWNER}/${REPO} PR #${PR_NUMBER}..."

read -r -d '' QUERY_JSON <<EOF
{
  "query":"query(\$owner:String!, \$name:String!, \$number:Int!){ repository(owner:\$owner, name:\$name) { pullRequest(number:\$number) { id number title mergeable mergeStateStatus } } }",
  "variables": {
    "owner": "${OWNER}",
    "name": "${REPO}",
    "number": ${PR_NUMBER}
  }
}
EOF

RESP=$(curl -sS -X POST -H "${AUTH_HEADER}" -H "${CONTENT_HEADER}" -d "$QUERY_JSON" "$GH_API_GRAPHQL")
ERRS=$(echo "$RESP" | jq -r '.errors?[]?.message' 2>/dev/null || true)
if [[ -n "$ERRS" ]]; then
  echo "GraphQL errors while fetching PR info:"
  echo "$RESP" | jq -r '.errors[]?.message'
  exit 1
fi

PR_NODE_ID=$(echo "$RESP" | jq -r '.data.repository.pullRequest.id // empty')
PR_TITLE=$(echo "$RESP" | jq -r '.data.repository.pullRequest.title // empty')
PR_MERGEABLE=$(echo "$RESP" | jq -r '.data.repository.pullRequest.mergeable // empty')
PR_MERGE_STATE=$(echo "$RESP" | jq -r '.data.repository.pullRequest.mergeStateStatus // empty')

if [[ -z "$PR_NODE_ID" ]]; then
  echo "ERROR: Could not retrieve PR node id. Response:"
  echo "$RESP" | jq
  exit 1
fi

echo "PR node id: $PR_NODE_ID"
echo "Title: $PR_TITLE"
echo "Mergeable: $PR_MERGEABLE, merge state: $PR_MERGE_STATE"
echo

echo "Enabling auto-merge (method: ${MERGE_METHOD})..."

read -r -d '' MUTATION_JSON <<EOF
{
  "query":"mutation(\$pullRequestId:ID!, \$method:PullRequestMergeMethod!){ enablePullRequestAutoMerge(input:{pullRequestId:\$pullRequestId, mergeMethod:\$method}) { pullRequest { number mergeable autoMergeEnabled } } }",
  "variables": {
    "pullRequestId": "${PR_NODE_ID}",
    "method": "${MERGE_METHOD}"
  }
}
EOF

MUT_RESP=$(curl -sS -X POST -H "${AUTH_HEADER}" -H "${CONTENT_HEADER}" -d "$MUTATION_JSON" "$GH_API_GRAPHQL")
MUT_ERRS=$(echo "$MUT_RESP" | jq -r '.errors[]?.message' 2>/dev/null || true)
if [[ -n "$MUT_ERRS" ]]; then
  echo "ERROR enabling auto-merge:"
  echo "$MUT_RESP" | jq -r '.errors[]?.message'
  echo
  echo "Full response:"
  echo "$MUT_RESP" | jq
  exit 1
fi

AUTO_MERGE_ENABLED=$(echo "$MUT_RESP" | jq -r '.data.enablePullRequestAutoMerge.pullRequest.autoMergeEnabled // false')
RETURN_PR_NUMBER=$(echo "$MUT_RESP" | jq -r '.data.enablePullRequestAutoMerge.pullRequest.number // empty')

if [[ "$AUTO_MERGE_ENABLED" == "true" ]]; then
  echo "Success: auto-merge enabled for PR #${RETURN_PR_NUMBER} (method: ${MERGE_METHOD})."
  echo "Mutation response:"
  echo "$MUT_RESP" | jq '.data.enablePullRequestAutoMerge.pullRequest'
  exit 0
else
  echo "Auto-merge not enabled. Full mutation response:"
  echo "$MUT_RESP" | jq
  exit 1
fi
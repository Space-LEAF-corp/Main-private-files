#!/usr/bin/env bash
set -euo pipefail

# Usage:
# 1) Place feature-microsoft-pay.patch in the root of your repo clone.
# 2) Make sure your origin points to your fork and upstream is set to Space-LEAF-Corp/platform
# 3) Run: ./apply_and_push_feature_microsoft_pay.sh
#
# This script will:
# - create branch feature/microsoft-pay
# - apply the patch with git am (creating commits)
# - run npm ci, npx prisma generate, and npx prisma migrate dev --name add_microsoft_integration
# - push branch to origin
# - optionally create a draft PR via gh (if gh is installed and authenticated)
#
# IMPORTANT:
# - Review patch before running (git am will create commits).
# - Ensure you have a local Postgres for npx prisma migrate dev (or set DATABASE_URL to a dev DB).
# - This script will NOT enable auto-merge; you'll need to enable auto-merge in GitHub UI or via gh api if permitted.

PATCH_FILE="feature-microsoft-pay.patch"
BRANCH="feature/microsoft-pay"
PR_TITLE="feat(payments): add Microsoft Pay integration"
PR_BODY_FILE="pr_description.md"
GIT_AUTHOR_NAME="${GIT_AUTHOR_NAME:-GuardianNinja}"
GIT_AUTHOR_EMAIL="${GIT_AUTHOR_EMAIL:-guardian@example.com}"

if [[ ! -f "$PATCH_FILE" ]]; then
  echo "Patch file $PATCH_FILE not found in current directory. Please place it here and re-run."
  exit 1
fi

# verify git status is clean
if [[ -n "$(git status --porcelain)" ]]; then
  echo "Working tree not clean. Commit or stash changes before running this script."
  git status --porcelain
  exit 1
fi

# create branch
git checkout -b "$BRANCH"

# apply patch (git am)
echo "Applying patch $PATCH_FILE ..."
git am --3way "$PATCH_FILE" || {
  echo "git am failed. You may need to resolve conflicts manually. Aborting."
  git am --abort || true
  exit 1
}

# Install dependencies
if command -v npm >/dev/null 2>&1; then
  echo "Installing npm deps (npm ci)..."
  npm ci
else
  echo "npm not found in PATH. Please install Node.js and npm, then run migrations manually."
fi

# Prisma generate
if command -v npx >/dev/null 2>&1; then
  echo "Generating Prisma client (npx prisma generate)..."
  npx prisma generate
else
  echo "npx not found in PATH. Install npm (Node.js) to run prisma commands."
fi

# Run migration dev (interactive)
echo "Running prisma migrate dev --name add_microsoft_integration"
# It will prompt for DB if DATABASE_URL not set or DB not available
npx prisma migrate dev --name add_microsoft_integration

# Push branch
echo "Pushing branch $BRANCH to origin..."
git push --set-upstream origin "$BRANCH"

# Optional: create draft PR with gh if available
if command -v gh >/dev/null 2>&1 && [[ -f "$PR_BODY_FILE" ]]; then
  echo "Creating draft PR using gh..."
  gh pr create --base main --head "$(git rev-parse --abbrev-ref HEAD)" --title "$PR_TITLE" --body-file "$PR_BODY_FILE" --draft
  echo "Draft PR created (if gh authenticated). Please enable auto-merge (squash) in the PR UI if desired."
else
  echo "gh CLI not found or $PR_BODY_FILE missing. Skip creating draft PR. You can create PR via GitHub UI or gh CLI manually."
fi

echo "Done. Branch '$BRANCH' pushed to origin. Create or enable draft PR and enable auto-merge if desired."
```markdown
# Microsoft Pay Integration Runbook

Overview
- Adds a Microsoft Pay integration for tenant-level onboarding, webhook handling, and token exchange.
- Secrets are stored via secret manager references (do not store plain secrets in DB).

Local setup
1. Copy .env.example -> .env and fill DATABASE_URL and local secret env vars.
2. Install deps:
   npm ci
3. Generate Prisma client:
   npx prisma generate
4. Run migration locally (dev):
   npx prisma migrate dev --name add_microsoft_integration
5. Start app:
   npm run dev

Testing
- Unit tests:
  npm test
- Integration tests:
  (ensure a test DB and run migrations) npx prisma migrate deploy
  npm run test:integration

OAuth onboarding (manual)
1. POST /integrations/microsoft/onboard with:
   {
     "tenantId": "...",
     "clientId": "...",
     "clientSecretRef": "secret://<path>",
     "webhookSecretRef": "secret://<path>",
     "displayName": "..."
   }
2. Follow authorizeUrl returned in response.
3. MS will redirect to MICROSOFT_PAY_CALLBACK_URL with code and state.

Webhook notes
- Webhook endpoint: POST /integrations/microsoft/webhook?integrationId=<id>
- Validate header x-microsoft-signature using HMAC SHA256 with webhook secret.
- Implement replay protection: store message IDs/timestamps to prevent replays.

Secrets & ops
- In production, store client secret / webhook secret / refresh tokens in a secure secret manager (AWS Secrets Manager, GCP Secret Manager, HashiCorp Vault).
- Ensure CI uses repository secrets for any integration tests.
- Rotate secrets regularly.

Rollback
- Revert migration via git (apply rollback migration if needed).
- Revoke app credentials in Microsoft portal.

Contacts
- Team / Pager: platform-oncall@example.com
- Owner: payments team
```
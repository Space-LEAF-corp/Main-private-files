-- Migration: add_microsoft_integration
-- Postgres-compatible SQL

CREATE TABLE "MicrosoftIntegration" (
  "id" TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
  "tenantId" TEXT NOT NULL,
  "displayName" TEXT,
  "clientId" TEXT NOT NULL,
  "clientSecretRef" TEXT NOT NULL,
  "webhookSecretRef" TEXT NOT NULL,
  "oauthRefreshTokenRef" TEXT,
  "createdAt" TIMESTAMP(3) DEFAULT now() NOT NULL,
  "updatedAt" TIMESTAMP(3) DEFAULT now() NOT NULL
);

CREATE INDEX "MicrosoftIntegration_tenantId_idx" ON "MicrosoftIntegration" ("tenantId");
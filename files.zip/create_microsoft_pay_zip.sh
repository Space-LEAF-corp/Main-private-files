#!/usr/bin/env bash
set -euo pipefail

# Creates the Microsoft Pay scaffold files and packages them into microsoft-pay-scaffold.zip
# Usage:
#   chmod +x create_microsoft_pay_zip.sh
#   ./create_microsoft_pay_zip.sh
#
# The script will create a subdirectory "microsoft-pay-scaffold" in the current directory,
# write all scaffold files there, then create microsoft-pay-scaffold.zip containing the files.
#
OUTDIR="microsoft-pay-scaffold"
ZIPNAME="microsoft-pay-scaffold.zip"

if [[ -d "$OUTDIR" ]]; then
  echo "Removing existing $OUTDIR ..."
  rm -rf "$OUTDIR"
fi

mkdir -p "$OUTDIR"

write() {
  local path="$OUTDIR/$1"
  mkdir -p "$(dirname "$path")"
  cat > "$path" <<'EOF'
'"$2"'
EOF
}

# Helper that writes file content (avoids variable interpolation)
write_content() {
  local path="$1"; shift
  mkdir -p "$OUTDIR/$(dirname "$path")"
  cat > "$OUTDIR/$path" <<'EOF'
$@
EOF
}

echo "Writing files into $OUTDIR ..."

# prisma/schema.prisma
cat > "$OUTDIR/prisma/schema.prisma" <<'EOF'
// Minimal Prisma schema additions for MicrosoftIntegration
// Merge into your existing prisma/schema.prisma, preserving existing generator and datasource blocks.

generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

model MicrosoftIntegration {
  id                        String   @id @default(uuid())
  tenantId                  String
  displayName               String?
  clientId                  String
  clientSecretRef           String   // reference key for secret manager (do NOT store raw secret)
  webhookSecretRef          String   // reference key for secret manager (do NOT store raw webhook secret)
  oauthRefreshTokenRef      String?  // optional ref to stored refresh token (secret manager)
  createdAt                 DateTime @default(now())
  updatedAt                 DateTime @updatedAt

  @@index([tenantId])
}
EOF

# prisma/migrations/.../migration.sql
mkdir -p "$OUTDIR/prisma/migrations/20251209120000_add_microsoft_integration"
cat > "$OUTDIR/prisma/migrations/20251209120000_add_microsoft_integration/migration.sql" <<'EOF'
-- Migration: add_microsoft_integration
-- Postgres-compatible SQL

CREATE TABLE "MicrosoftIntegration" (
  "id" TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
  "tenantId" TEXT NOT NULL,
  "displayName" TEXT,
  "clientId" TEXT NOT NULL,
  "clientSecretRef" TEXT NOT NULL,
  "webhookSecretRef" TEXT NOT NULL,
  "oauthRefreshTokenRef" TEXT,
  "createdAt" TIMESTAMP(3) DEFAULT now() NOT NULL,
  "updatedAt" TIMESTAMP(3) DEFAULT now() NOT NULL
);

CREATE INDEX "MicrosoftIntegration_tenantId_idx" ON "MicrosoftIntegration" ("tenantId");
EOF

# src/app.ts
mkdir -p "$OUTDIR/src"
cat > "$OUTDIR/src/app.ts" <<'EOF'
// Example app entry. If your app entry differs, adapt the mounting lines shown here.
// This file must export the Express app (default export) so tests can import it.

import express from 'express';
import microsoftRoutes from './routes/microsoftPay/routes';

const app = express();

// Your existing middleware (bodyParser, auth, etc.) should be kept here.
// Example:
app.use(express.json());

// Mount Microsoft Pay integration routes under /integrations/microsoft
app.use('/integrations/microsoft', microsoftRoutes);

// Example health route
app.get('/health', (req, res) => res.status(200).json({ ok: true }));

export default app;
EOF

# src/lib/prismaClient.ts
cat > "$OUTDIR/src/lib/prismaClient.ts" <<'EOF'
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export default prisma;
EOF

# src/services/microsoftPay/secretManager.ts
mkdir -p "$OUTDIR/src/services/microsoftPay"
cat > "$OUTDIR/src/services/microsoftPay/secretManager.ts" <<'EOF'
// Minimal secret manager abstraction. Implementers should replace stubs with
// actual AWS/GCP/Vault secret retrieval (and caching) based on environment.

export async function getSecretByReference(ref: string): Promise<string | null> {
  // Example reference format: "secret://microsoft-integration/tenant-123/webhook"
  // For local testing we can map ref to env var: secret://x/y -> SECRET__X__Y
  const envKey = ref.replace(/[:\/\-]/g, '_').replace(/__+/g, '_').toUpperCase();
  if (process.env[envKey]) {
    return process.env[envKey] || null;
  }

  // TODO: detect and fetch from cloud secret managers:
  // - AWS Secrets Manager / Parameter Store
  // - GCP Secret Manager
  // - HashiCorp Vault
  // Implement caching & rotation logic in production.

  return null;
}
EOF

# src/services/microsoftPay/service.ts
cat > "$OUTDIR/src/services/microsoftPay/service.ts" <<'EOF'
import axios from 'axios';
import prisma from '../../lib/prismaClient';
import { getSecretByReference } from './secretManager';
import { verifyWebhookSignature } from '../../utils/microsoftPay/signature';

export interface IntegrationCreateInput {
  tenantId: string;
  displayName?: string;
  clientId: string;
  clientSecretRef: string;
  webhookSecretRef: string;
}

/**
 * Persist a new MicrosoftIntegration (note: secrets are referenced, not stored)
 */
export async function createIntegration(input: IntegrationCreateInput) {
  return prisma.microsoftIntegration.create({
    data: {
      tenantId: input.tenantId,
      displayName: input.displayName,
      clientId: input.clientId,
      clientSecretRef: input.clientSecretRef,
      webhookSecretRef: input.webhookSecretRef,
    },
  });
}

/**
 * Exchange an authorization code for tokens using MS endpoint.
 * This function uses clientSecret fetched via secret manager.
 */
export async function exchangeCodeForToken(
  integrationId: string,
  code: string,
  redirectUri: string
) {
  const integration = await prisma.microsoftIntegration.findUnique({
    where: { id: integrationId },
  });
  if (!integration) throw new Error('Integration not found');

  const clientSecret = await getSecretByReference(integration.clientSecretRef);
  if (!clientSecret) throw new Error('Client secret not available');

  const tokenUrl = 'https://login.microsoftonline.com/common/oauth2/v2.0/token';

  const params = new URLSearchParams();
  params.append('client_id', integration.clientId);
  params.append('client_secret', clientSecret);
  params.append('grant_type', 'authorization_code');
  params.append('code', code);
  params.append('redirect_uri', redirectUri);

  const resp = await axios.post(tokenUrl, params.toString(), {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  });

  // Store refresh token as a secret reference or in your secret manager
  // This scaffold DOES NOT write secrets; implementers must write refresh_token to secret manager
  const refreshToken = resp.data.refresh_token;
  // TODO: write refreshToken to secret manager and set oauthRefreshTokenRef on integration

  return resp.data;
}

/**
 * Verify webhook signature and prevent replay attacks
 */
export async function handleWebhook(integrationId: string, payload: Buffer, signature: string, timestamp?: string) {
  const integration = await prisma.microsoftIntegration.findUnique({
    where: { id: integrationId },
  });
  if (!integration) throw new Error('Integration not found');
  const webhookSecret = await getSecretByReference(integration.webhookSecretRef);
  if (!webhookSecret) throw new Error('Webhook secret not available');

  const ok = verifyWebhookSignature(payload, signature, webhookSecret, timestamp);
  if (!ok) {
    const e: any = new Error('Invalid signature');
    e.code = 'INVALID_SIGNATURE';
    throw e;
  }

  // TODO: replay detection / idempotency using a dedup table or cache.

  // Process webhook (business logic goes here)
  return { ok: true };
}
EOF

# src/utils/microsoftPay/signature.ts
mkdir -p "$OUTDIR/src/utils/microsoftPay"
cat > "$OUTDIR/src/utils/microsoftPay/signature.ts" <<'EOF'
import crypto from 'crypto';

/**
 * Verify HMAC signature for webhook.
 * Adapt to Microsoft Pay exact webhook format if it differs (headers, signed payload).
 */
export function computeHmac(payload: Buffer | string, secret: string) {
  return crypto.createHmac('sha256', secret).update(payload).digest('hex');
}

export function timingSafeEqual(a: string, b: string) {
  const bufA = Buffer.from(a, 'utf8');
  const bufB = Buffer.from(b, 'utf8');
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

export function verifyWebhookSignature(payload: Buffer, signatureHeader: string, secret: string, timestamp?: string): boolean {
  // If Microsoft Pay requires timestamped signature, include timestamp in stringToSign
  const toSign = payload;
  const expected = computeHmac(toSign, secret);
  return timingSafeEqual(expected, signatureHeader);
}
EOF

# src/middleware/microsoftPay/requireTenantAdmin.ts
mkdir -p "$OUTDIR/src/middleware/microsoftPay"
cat > "$OUTDIR/src/middleware/microsoftPay/requireTenantAdmin.ts" <<'EOF'
import { Request, Response, NextFunction } from 'express';

/**
 * Simple middleware stub: expects req.user to exist and have role 'tenant_admin' or 'super_admin' for tenant.
 * Replace tenantAuthAdapter logic with your real RBAC checks.
 */
export default function requireTenantAdmin(req: Request, res: Response, next: NextFunction) {
  const user = (req as any).user;
  if (!user) return res.status(401).json({ error: 'Unauthorized' });

  // Replace this with tenant-level admin check (tenant id should be available on req)
  if (user.role !== 'tenant_admin' && user.role !== 'super_admin') {
    return res.status(403).json({ error: 'Require tenant admin' });
  }

  next();
}
EOF

# src/controllers/microsoftPay/controller.ts
mkdir -p "$OUTDIR/src/controllers/microsoftPay"
cat > "$OUTDIR/src/controllers/microsoftPay/controller.ts" <<'EOF'
import { Request, Response } from 'express';
import { createIntegration, exchangeCodeForToken, handleWebhook } from '../../services/microsoftPay/service';
import prisma from '../../lib/prismaClient';

/**
 * /integrations/microsoft/onboard
 * Accepts JSON with clientId, clientSecretRef, webhookSecretRef, displayName, tenantId
 * Responds with an onboarding URL (OAuth authorize URL).
 */
export async function onboard(req: Request, res: Response) {
  const { tenantId, clientId, clientSecretRef, webhookSecretRef, displayName } = req.body;

  if (!tenantId || !clientId || !clientSecretRef || !webhookSecretRef) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const integration = await createIntegration({
    tenantId,
    displayName,
    clientId,
    clientSecretRef,
    webhookSecretRef,
  });

  // Build native MS OAuth authorization URL
  const params = new URLSearchParams({
    client_id: integration.clientId,
    response_type: 'code',
    redirect_uri: process.env.MICROSOFT_PAY_CALLBACK_URL || 'https://example.com/integrations/microsoft/callback',
    scope: 'offline_access openid', // example scopes
    state: `${integration.id}`, // NOTE: production should HMAC/sign state or store DB state
  });

  const url = `https://login.microsoftonline.com/common/oauth2/v2.0/authorize?${params.toString()}`;
  return res.status(201).json({ integrationId: integration.id, authorizeUrl: url });
}

/**
 * /integrations/microsoft/callback
 * Handles OAuth callback with code and state
 */
export async function callback(req: Request, res: Response) {
  const { code, state } = req.query;
  if (!code || !state) return res.status(400).send('Missing code/state');

  try {
    const tokenResp = await exchangeCodeForToken(String(state), String(code), process.env.MICROSOFT_PAY_CALLBACK_URL || '');
    // You may want to store token metadata / update integration record
    await prisma.microsoftIntegration.update({
      where: { id: String(state) },
      data: {
        // In production, store a reference to the refresh token in secret manager
        // oauthRefreshTokenRef: 'secret://microsoft/refreshs/..'
      } as any,
    });

    return res.status(200).json({ ok: true, token: tokenResp });
  } catch (err: any) {
    console.error('OAuth callback failed', err);
    return res.status(500).json({ error: 'OAuth exchange failed' });
  }
}

/**
 * /integrations/microsoft/api-key
 * Example: return an API key or perform key rotation (stub)
 */
export async function apiKey(req: Request, res: Response) {
  // Example: ensure tenant has integration then produce ephemeral API key
  const { integrationId } = req.body;
  if (!integrationId) return res.status(400).json({ error: 'integrationId required' });

  // TODO: implement real API key generation & secret storage
  return res.status(200).json({ apiKey: `test_key_${integrationId}` });
}

/**
 * /integrations/microsoft/webhook
 */
export async function webhook(req: Request, res: Response) {
  try {
    const signature = req.header('x-microsoft-signature') || '';
    const timestamp = req.header('x-microsoft-timestamp') || undefined;
    const integrationId = req.query.integrationId as string | undefined;
    if (!integrationId) return res.status(400).json({ error: 'integrationId query required' });

    const payload = Buffer.from(JSON.stringify(req.body));
    await handleWebhook(integrationId, payload, signature, timestamp);
    return res.status(200).json({ ok: true });
  } catch (err: any) {
    if (err.code === 'INVALID_SIGNATURE') return res.status(401).json({ error: 'Invalid signature' });
    console.error('webhook processing error', err);
    return res.status(500).json({ error: 'processing error' });
  }
}
EOF

# src/routes/microsoftPay/routes.ts
mkdir -p "$OUTDIR/src/routes/microsoftPay"
cat > "$OUTDIR/src/routes/microsoftPay/routes.ts" <<'EOF'
import express from 'express';
import * as controller from '../../controllers/microsoftPay/controller';
import requireTenantAdmin from '../../middleware/microsoftPay/requireTenantAdmin';

const router = express.Router();

// Onboard (create integration record + provide OAuth URL)
router.post('/onboard', requireTenantAdmin, controller.onboard);

// OAuth callback (public)
router.get('/callback', controller.callback);

// API key endpoint (protected)
router.post('/api-key', requireTenantAdmin, controller.apiKey);

// Webhook receiver (public, signature validated)
router.post('/webhook', express.json(), controller.webhook);

export default router;
EOF

# tests/unit/microsoftPay/service.test.ts
mkdir -p "$OUTDIR/tests/unit/microsoftPay"
cat > "$OUTDIR/tests/unit/microsoftPay/service.test.ts" <<'EOF'
import { exchangeCodeForToken, createIntegration } from '../../../src/services/microsoftPay/service';
import prisma from '../../../src/lib/prismaClient';
import axios from 'axios';
import { getSecretByReference } from '../../../src/services/microsoftPay/secretManager';

jest.mock('../../../src/lib/prismaClient');
jest.mock('axios');
jest.mock('../../../src/services/microsoftPay/secretManager');

const mockedAxios = axios as jest.Mocked<typeof axios>;
const mockedPrisma = prisma as any;
const mockedSecret = getSecretByReference as jest.MockedFunction<typeof getSecretByReference>;

describe('MicrosoftPay service', () => {
  afterEach(() => jest.resetAllMocks());

  test('exchangeCodeForToken throws if integration missing', async () => {
    mockedPrisma.microsoftIntegration.findUnique.mockResolvedValue(null);
    await expect(exchangeCodeForToken('nonexistent', 'code', 'http://c')).rejects.toThrow('Integration not found');
  });

  test('exchangeCodeForToken calls token endpoint', async () => {
    mockedPrisma.microsoftIntegration.findUnique.mockResolvedValue({
      id: 'i1',
      clientId: 'cid',
      clientSecretRef: 'secret://c',
      webhookSecretRef: 'wref',
    });
    mockedSecret.mockResolvedValue('supersecret');
    mockedAxios.post.mockResolvedValue({ data: { access_token: 'at', refresh_token: 'rt' } });

    const resp = await exchangeCodeForToken('i1', 'AUTH_CODE', 'https://cb');
    expect(resp.access_token).toBe('at');
    expect(mockedAxios.post).toHaveBeenCalled();
  });
});
EOF

# tests/integration/microsoftPay/e2e.test.ts
mkdir -p "$OUTDIR/tests/integration/microsoftPay"
cat > "$OUTDIR/tests/integration/microsoftPay/e2e.test.ts" <<'EOF'
// integration e2e test using supertest
// Note: this is a scaffold. You must import your express app and mount the routes in test setup.

const request = require('supertest');
// Ensure your src/app.ts exports the app as default:
const app = require('../../src/app').default;

describe('MicrosoftPay e2e', () => {
  test('onboard requires auth', async () => {
    const res = await request(app)
      .post('/integrations/microsoft/onboard')
      .send({ tenantId: 't1', clientId: 'cid', clientSecretRef: 'secret://c', webhookSecretRef: 'secret://w' });
    expect([401,403]).toContain(res.statusCode);
  });
});
EOF

# .env.example
cat > "$OUTDIR/.env.example" <<'EOF'
# Example environment variables for Microsoft Pay integration
DATABASE_URL=postgresql://user:pass@localhost:5432/dbname
MICROSOFT_PAY_CALLBACK_URL=https://localhost:3000/integrations/microsoft/callback

# Secret references (local/testing only - in production use secret manager)
SECRET__MICROSOFT_INTEGRATION_CLIENT_SECRET=example_local_client_secret
SECRET__MICROSOFT_INTEGRATION_WEBHOOK_SECRET=example_local_webhook_secret

# Optional flags for secret manager detection
AWS_REGION=
GCP_PROJECT=

# App env
NODE_ENV=development
PORT=3000
EOF

# .github workflow
mkdir -p "$OUTDIR/.github/workflows"
cat > "$OUTDIR/.github/workflows/microsoft-pay-ci.yml" <<'EOF'
name: Microsoft Pay CI

on:
  pull_request:
    paths:
      - 'src/**'
      - 'prisma/**'
      - '.github/workflows/**'
      - 'tests/**'

jobs:
  test:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:15
        ports:
          - 5432:5432
        env:
          POSTGRES_USER: postgres
          POSTGRES_PASSWORD: postgres
          POSTGRES_DB: testdb
        options: >-
          --health-cmd "pg_isready -U postgres -d testdb" --health-interval 10s
          --health-timeout 5s --health-retries 5

    env:
      DATABASE_URL: postgres://postgres:postgres@localhost:5432/testdb
    steps:
      - uses: actions/checkout@v4

      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: '18'
          cache: 'npm'

      - name: Install deps
        run: npm ci

      - name: Generate Prisma client
        run: npx prisma generate

      - name: Apply migrations (test DB)
        run: npx prisma migrate deploy

      - name: Run tests
        run: npm test

      - name: Run gitleaks (simple scan)
        uses: zricethezav/gitleaks-action@v1
        with:
          args: '--redact'
EOF

# docs/runbooks/microsoft-pay.md
mkdir -p "$OUTDIR/docs"
cat > "$OUTDIR/docs/runbooks/microsoft-pay.md" <<'EOF'
# Microsoft Pay Integration Runbook

Overview
- Adds a Microsoft Pay integration for tenant-level onboarding, webhook handling, and token exchange.
- Secrets are stored via secret manager references (do not store plain secrets in DB).

Local setup
1. Copy .env.example -> .env and fill DATABASE_URL and local secret env vars.
2. Install deps:
   npm ci
3. Generate Prisma client:
   npx prisma generate
4. Run migration locally (dev):
   npx prisma migrate dev --name add_microsoft_integration
5. Start app:
   npm run dev

Testing
- Unit tests:
  npm test
- Integration tests:
  (ensure a test DB and run migrations) npx prisma migrate deploy
  npm run test:integration

OAuth onboarding (manual)
1. POST /integrations/microsoft/onboard with:
   {
     "tenantId": "...",
     "clientId": "...",
     "clientSecretRef": "secret://<path>",
     "webhookSecretRef": "secret://<path>",
     "displayName": "..."
   }
2. Follow authorizeUrl returned in response.
3. MS will redirect to MICROSOFT_PAY_CALLBACK_URL with code and state.

Webhook notes
- Webhook endpoint: POST /integrations/microsoft/webhook?integrationId=<id>
- Validate header x-microsoft-signature using HMAC SHA256 with webhook secret.
- Implement replay protection: store message IDs/timestamps to prevent replays.

Secrets & ops
- In production, store client secret / webhook secret / refresh tokens in a secure secret manager (AWS Secrets Manager, GCP Secret Manager, HashiCorp Vault).
- Ensure CI uses repository secrets for any integration tests.
- Rotate secrets regularly.

Rollback
- Revert migration via git (apply rollback migration if needed).
- Revoke app credentials in Microsoft portal.

Contacts
- Team / Pager: platform-oncall@example.com
- Owner: payments team
EOF

# pr_description.md
cat > "$OUTDIR/pr_description.md" <<'EOF'
Title: feat(payments): add Microsoft Pay integration

What:
- Adds Microsoft Pay integration scaffold:
  - Prisma schema + generated migration (prisma/migrations/20251209120000_add_microsoft_integration)
  - TypeScript services, controllers, routes, middleware
  - Webhook signature verification and replay-protection stubs
  - Secret manager abstraction (local/env fallback; AWS/GCP/Vault hooks TODO)
  - Unit & integration tests (mocks)
  - .env.example, runbook (docs/runbooks/microsoft-pay.md)
  - CI workflow (.github/workflows/microsoft-pay-ci.yml)

Why:
- Add Microsoft Pay as a tenant-scoped payment integration.

How to test locally:
1. npm ci
2. npx prisma generate
3. npx prisma migrate dev --name add_microsoft_integration
4. npm test

Reviewer checklist:
- [ ] Verify Prisma schema changes and migration run cleanly (npx prisma migrate dev --name add_microsoft_integration).
- [ ] Confirm API routes and controllers follow repo patterns and have proper typing.
- [ ] Run tests locally and confirm they pass; confirm CI run passes.
- [ ] Verify .env.example contains required keys and guidance.
- [ ] Validate README / runbook steps are clear for QA and ops.
- [ ] Security review: no plaintext secrets committed; secret manager usage; token handling and rotation.
- [ ] Wire getSecretByReference to chosen secret manager (AWS Secrets Manager / GCP Secret Manager / Vault) and implement oauthRefreshTokenRef storage.
- [ ] Replace tenantAuthAdapter stubs with real RBAC logic.

Notes:
- Migration folder included for review and CI reproducibility.
- No real secrets included in this PR. Replace placeholder secret refs with real secret manager writes in ops.
EOF

echo "Creating zip $ZIPNAME ..."
cd "$OUTDIR"
zip -r "../$ZIPNAME" . >/dev/null
cd ..

echo "Zip created: $ZIPNAME (contains directory $OUTDIR)"
echo
echo "Next steps:"
echo " - Download or attach $ZIPNAME to email to Microsoft or upload to your storage."
echo " - If you will import into a repo, unpack and review files first:"
echo "     unzip $ZIPNAME -d microsoft-pay-unpack"
echo " - Remember to replace secret manager stubs and RBAC stubs before deploying."
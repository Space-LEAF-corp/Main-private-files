#!/usr/bin/env bash
# enable_auto_merge_rest.sh
#
# Enables auto-merge for a PR via the REST endpoint:
#   PUT /repos/{owner}/{repo}/pulls/{pull_number}/auto_merge
#
# Usage:
#   export GITHUB_TOKEN="ghp_XXXXXXXXXXXX"
#   ./enable_auto_merge_rest.sh <PR_NUMBER> <OWNER> <REPO> [MERGE_METHOD]
#
# Example:
#   ./enable_auto_merge_rest.sh 123 Space-LEAF-Corp platform squash
#
# MERGE_METHOD: squash (default) | rebase | merge
#
set -euo pipefail

if ! command -v curl >/dev/null 2>&1; then
  echo "ERROR: curl is required"
  exit 1
fi
if ! command -v jq >/dev/null 2>&1; then
  echo "ERROR: jq is required"
  exit 1
fi

if [[ -z "${GITHUB_TOKEN:-}" ]]; then
  echo "ERROR: GITHUB_TOKEN environment variable not set."
  echo "Export it: export GITHUB_TOKEN='ghp_...'"
  exit 1
fi

PR_NUMBER="${1:-}"
OWNER="${2:-}"
REPO="${3:-}"
MERGE_METHOD="${4:-squash}" # squash | rebase | merge

if [[ -z "$PR_NUMBER" || -z "$OWNER" || -z "$REPO" ]]; then
  cat <<EOF
Usage: $0 <PR_NUMBER> <OWNER> <REPO> [MERGE_METHOD]
Example: $0 123 Space-LEAF-Corp platform squash
EOF
  exit 1
fi

API_URL="https://api.github.com/repos/${OWNER}/${REPO}/pulls/${PR_NUMBER}/auto_merge"
AUTH_HEADER="Authorization: Bearer ${GITHUB_TOKEN}"
CONTENT_HEADER="Accept: application/vnd.github+json"

echo "Enabling auto-merge for ${OWNER}/${REPO} PR #${PR_NUMBER} (method: ${MERGE_METHOD})..."

PAYLOAD=$(jq -n --arg method "$MERGE_METHOD" '{merge_method: $method}')

RESP=$(curl -sS -X PUT -H "${AUTH_HEADER}" -H "${CONTENT_HEADER}" -d "$PAYLOAD" "$API_URL" -w "\n%{http_code}")

# Separate body and status
HTTP_BODY=$(echo "$RESP" | sed '$d')
HTTP_STATUS=$(echo "$RESP" | tail -n1)

if [[ "$HTTP_STATUS" =~ ^2 ]]; then
  echo "Auto-merge enabled (HTTP $HTTP_STATUS). Response body:"
  echo "$HTTP_BODY" | jq
  exit 0
else
  echo "Failed to enable auto-merge (HTTP $HTTP_STATUS). Response:"
  # Try pretty print or raw
  if echo "$HTTP_BODY" | jq . >/dev/null 2>&1; then
    echo "$HTTP_BODY" | jq
  else
    echo "$HTTP_BODY"
  fi
  # Helpful debugging hints
  echo
  echo "Hints:"
  echo "- Ensure the token has repo permissions and the caller has permission to enable auto-merge."
  echo "- Check repository settings: auto-merge may be disabled at org or repo level."
  echo "- Confirm PR is mergeable and required checks are configured."
  echo "- To inspect PR details:"
  echo "  curl -H \"Authorization: Bearer \$GITHUB_TOKEN\" -H \"Accept: application/vnd.github+json\" https://api.github.com/repos/${OWNER}/${REPO}/pulls/${PR_NUMBER} | jq '.'"
  exit 1
fi
```markdown
Title: feat(payments): add Microsoft Pay integration

What:
- Adds Microsoft Pay integration scaffold:
  - Prisma schema + generated migration (prisma/migrations/20251209120000_add_microsoft_integration)
  - TypeScript services, controllers, routes, middleware
  - Webhook signature verification and replay-protection stubs
  - Secret manager abstraction (local/env fallback; AWS/GCP/Vault hooks TODO)
  - Unit & integration tests (mocks)
  - .env.example, runbook (docs/runbooks/microsoft-pay.md)
  - CI workflow (.github/workflows/microsoft-pay-ci.yml)

Why:
- Add Microsoft Pay as a tenant-scoped payment integration.

How to test locally:
1. npm ci
2. npx prisma generate
3. npx prisma migrate dev --name add_microsoft_integration
4. npm test

Reviewer checklist:
- [ ] Verify Prisma schema changes and migration run cleanly (npx prisma migrate dev --name add_microsoft_integration).
- [ ] Confirm API routes and controllers follow repo patterns and have proper typing.
- [ ] Run tests locally and confirm they pass; confirm CI run passes.
- [ ] Verify .env.example contains required keys and guidance.
- [ ] Validate README / runbook steps are clear for QA and ops.
- [ ] Security review: no plaintext secrets committed; secret manager usage; token handling and rotation.
- [ ] Wire getSecretByReference to chosen secret manager (AWS Secrets Manager / GCP Secret Manager / Vault) and implement oauthRefreshTokenRef storage.
- [ ] Replace tenantAuthAdapter stubs with real RBAC logic.

Notes:
- Migration folder included for review and CI reproducibility.
- No real secrets included in this PR. Replace placeholder secret refs with real secret manager writes in ops.
```
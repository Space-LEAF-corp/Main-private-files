// Example app entry. If your app entry differs, adapt the mounting lines shown here.
// This file must export the Express app (default export) so tests can import it.

import express from 'express';
import microsoftRoutes from './routes/microsoftPay/routes';

const app = express();

// Your existing middleware (bodyParser, auth, etc.) should be kept here.
// Example:
app.use(express.json());

// Mount Microsoft Pay integration routes under /integrations/microsoft
app.use('/integrations/microsoft', microsoftRoutes);

// Example health route
app.get('/health', (req, res) => res.status(200).json({ ok: true }));

export default app;
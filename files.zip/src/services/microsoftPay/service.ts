import axios from 'axios';
import prisma from '../../lib/prismaClient';
import { getSecretByReference } from './secretManager';
import { verifyWebhookSignature } from '../../utils/microsoftPay/signature';

export interface IntegrationCreateInput {
  tenantId: string;
  displayName?: string;
  clientId: string;
  clientSecretRef: string;
  webhookSecretRef: string;
}

/**
 * Persist a new MicrosoftIntegration (note: secrets are referenced, not stored)
 */
export async function createIntegration(input: IntegrationCreateInput) {
  return prisma.microsoftIntegration.create({
    data: {
      tenantId: input.tenantId,
      displayName: input.displayName,
      clientId: input.clientId,
      clientSecretRef: input.clientSecretRef,
      webhookSecretRef: input.webhookSecretRef,
    },
  });
}

/**
 * Exchange an authorization code for tokens using MS endpoint.
 * This function uses clientSecret fetched via secret manager.
 */
export async function exchangeCodeForToken(
  integrationId: string,
  code: string,
  redirectUri: string
) {
  const integration = await prisma.microsoftIntegration.findUnique({
    where: { id: integrationId },
  });
  if (!integration) throw new Error('Integration not found');

  const clientSecret = await getSecretByReference(integration.clientSecretRef);
  if (!clientSecret) throw new Error('Client secret not available');

  const tokenUrl = 'https://login.microsoftonline.com/common/oauth2/v2.0/token';

  const params = new URLSearchParams();
  params.append('client_id', integration.clientId);
  params.append('client_secret', clientSecret);
  params.append('grant_type', 'authorization_code');
  params.append('code', code);
  params.append('redirect_uri', redirectUri);

  const resp = await axios.post(tokenUrl, params.toString(), {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  });

  // Store refresh token as a secret reference or in your secret manager
  // This scaffold DOES NOT write secrets; implementers must write refresh_token to secret manager
  const refreshToken = resp.data.refresh_token;
  // TODO: write refreshToken to secret manager and set oauthRefreshTokenRef on integration

  return resp.data;
}

/**
 * Verify webhook signature and prevent replay attacks
 */
export async function handleWebhook(integrationId: string, payload: Buffer, signature: string, timestamp?: string) {
  const integration = await prisma.microsoftIntegration.findUnique({
    where: { id: integrationId },
  });
  if (!integration) throw new Error('Integration not found');
  const webhookSecret = await getSecretByReference(integration.webhookSecretRef);
  if (!webhookSecret) throw new Error('Webhook secret not available');

  const ok = verifyWebhookSignature(payload, signature, webhookSecret, timestamp);
  if (!ok) {
    const e: any = new Error('Invalid signature');
    e.code = 'INVALID_SIGNATURE';
    throw e;
  }

  // TODO: replay detection / idempotency using a dedup table or cache.

  // Process webhook (business logic goes here)
  return { ok: true };
}
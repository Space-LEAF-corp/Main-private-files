import { Request, Response } from 'express';
import { createIntegration, exchangeCodeForToken, handleWebhook } from '../../services/microsoftPay/service';
import prisma from '../../lib/prismaClient';

/**
 * /integrations/microsoft/onboard
 * Accepts JSON with clientId, clientSecretRef, webhookSecretRef, displayName, tenantId
 * Responds with an onboarding URL (OAuth authorize URL).
 */
export async function onboard(req: Request, res: Response) {
  const { tenantId, clientId, clientSecretRef, webhookSecretRef, displayName } = req.body;

  if (!tenantId || !clientId || !clientSecretRef || !webhookSecretRef) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const integration = await createIntegration({
    tenantId,
    displayName,
    clientId,
    clientSecretRef,
    webhookSecretRef,
  });

  // Build native MS OAuth authorization URL
  const params = new URLSearchParams({
    client_id: integration.clientId,
    response_type: 'code',
    redirect_uri: process.env.MICROSOFT_PAY_CALLBACK_URL || 'https://example.com/integrations/microsoft/callback',
    scope: 'offline_access openid', // example scopes
    state: `${integration.id}`, // NOTE: production should HMAC/sign state or store DB state
  });

  const url = `https://login.microsoftonline.com/common/oauth2/v2.0/authorize?${params.toString()}`;
  return res.status(201).json({ integrationId: integration.id, authorizeUrl: url });
}

/**
 * /integrations/microsoft/callback
 * Handles OAuth callback with code and state
 */
export async function callback(req: Request, res: Response) {
  const { code, state } = req.query;
  if (!code || !state) return res.status(400).send('Missing code/state');

  try {
    const tokenResp = await exchangeCodeForToken(String(state), String(code), process.env.MICROSOFT_PAY_CALLBACK_URL || '');
    // You may want to store token metadata / update integration record
    await prisma.microsoftIntegration.update({
      where: { id: String(state) },
      data: {
        // In production, store a reference to the refresh token in secret manager
        // oauthRefreshTokenRef: 'secret://microsoft/refreshs/..'
      } as any,
    });

    return res.status(200).json({ ok: true, token: tokenResp });
  } catch (err: any) {
    console.error('OAuth callback failed', err);
    return res.status(500).json({ error: 'OAuth exchange failed' });
  }
}

/**
 * /integrations/microsoft/api-key
 * Example: return an API key or perform key rotation (stub)
 */
export async function apiKey(req: Request, res: Response) {
  // Example: ensure tenant has integration then produce ephemeral API key
  const { integrationId } = req.body;
  if (!integrationId) return res.status(400).json({ error: 'integrationId required' });

  // TODO: implement real API key generation & secret storage
  return res.status(200).json({ apiKey: `test_key_${integrationId}` });
}

/**
 * /integrations/microsoft/webhook
 */
export async function webhook(req: Request, res: Response) {
  try {
    const signature = req.header('x-microsoft-signature') || '';
    const timestamp = req.header('x-microsoft-timestamp') || undefined;
    const integrationId = req.query.integrationId as string | undefined;
    if (!integrationId) return res.status(400).json({ error: 'integrationId query required' });

    const payload = Buffer.from(JSON.stringify(req.body));
    await handleWebhook(integrationId, payload, signature, timestamp);
    return res.status(200).json({ ok: true });
  } catch (err: any) {
    if (err.code === 'INVALID_SIGNATURE') return res.status(401).json({ error: 'Invalid signature' });
    console.error('webhook processing error', err);
    return res.status(500).json({ error: 'processing error' });
  }
}
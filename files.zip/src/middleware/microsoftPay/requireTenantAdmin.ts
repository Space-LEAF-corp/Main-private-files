import { Request, Response, NextFunction } from 'express';

/**
 * Simple middleware stub: expects req.user to exist and have role 'tenant_admin' or 'super_admin' for tenant.
 * Replace tenantAuthAdapter logic with your real RBAC checks.
 */
export default function requireTenantAdmin(req: Request, res: Response, next: NextFunction) {
  const user = (req as any).user;
  if (!user) return res.status(401).json({ error: 'Unauthorized' });

  // Replace this with tenant-level admin check (tenant id should be available on req)
  if (user.role !== 'tenant_admin' && user.role !== 'super_admin') {
    return res.status(403).json({ error: 'Require tenant admin' });
  }

  next();
}
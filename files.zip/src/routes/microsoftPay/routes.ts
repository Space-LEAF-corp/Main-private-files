import express from 'express';
import * as controller from '../../controllers/microsoftPay/controller';
import requireTenantAdmin from '../../middleware/microsoftPay/requireTenantAdmin';

const router = express.Router();

// Onboard (create integration record + provide OAuth URL)
router.post('/onboard', requireTenantAdmin, controller.onboard);

// OAuth callback (public)
router.get('/callback', controller.callback);

// API key endpoint (protected)
router.post('/api-key', requireTenantAdmin, controller.apiKey);

// Webhook receiver (public, signature validated)
router.post('/webhook', express.json(), controller.webhook);

export default router;
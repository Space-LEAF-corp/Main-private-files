import crypto from 'crypto';

/**
 * Verify HMAC signature for webhook.
 * Adapt to Microsoft Pay exact webhook format if it differs (headers, signed payload).
 */
export function computeHmac(payload: Buffer | string, secret: string) {
  return crypto.createHmac('sha256', secret).update(payload).digest('hex');
}

export function timingSafeEqual(a: string, b: string) {
  const bufA = Buffer.from(a, 'utf8');
  const bufB = Buffer.from(b, 'utf8');
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

export function verifyWebhookSignature(payload: Buffer, signatureHeader: string, secret: string, timestamp?: string): boolean {
  // If Microsoft Pay requires timestamped signature, include timestamp in stringToSign
  const toSign = payload;
  const expected = computeHmac(toSign, secret);
  return timingSafeEqual(expected, signatureHeader);
}
#!/usr/bin/env bash
#
# enable_and_wait_merge.sh
#
# Usage:
#   export GITHUB_TOKEN="ghp_xxx"     # must have repo write/admin permission
#   ./enable_and_wait_merge.sh <PR_NUMBER> <OWNER> <REPO> [--run-migrate]
#
# Example:
#   ./enable_and_wait_merge.sh 123 Space-LEAF-Corp platform --run-migrate
#
# What it does:
# 1) Runs tests locally (npm test or yarn test)
# 2) Optionally runs npx prisma generate and npx prisma migrate dev --name add_microsoft_integration
# 3) Enables auto-merge (squash) for the PR via GitHub REST API
# 4) Polls the PR until merged or timeout
#
# Notes:
# - Do NOT paste your GITHUB_TOKEN here. Keep it secret.
# - Ensure branch for PR is already pushed.
# - jq and curl required. npm/yarn/npx required to run tests & prisma commands.
#
set -euo pipefail

if ! command -v curl >/dev/null 2>&1; then
  echo "ERROR: curl is required."
  exit 1
fi
if ! command -v jq >/dev/null 2>&1; then
  echo "ERROR: jq is required."
  exit 1
fi

PR_NUMBER="${1:-}"
OWNER="${2:-}"
REPO="${3:-}"
RUN_MIGRATE_FLAG="${4:-}"

if [[ -z "$PR_NUMBER" || -z "$OWNER" || -z "$REPO" ]]; then
  echo "Usage: $0 <PR_NUMBER> <OWNER> <REPO> [--run-migrate]"
  exit 1
fi

if [[ -z "${GITHUB_TOKEN:-}" ]]; then
  echo "ERROR: GITHUB_TOKEN not set. Export it first (do not paste it here)."
  exit 1
fi

API_URL_REPO="https://api.github.com/repos/${OWNER}/${REPO}"
API_URL_PR="${API_URL_REPO}/pulls/${PR_NUMBER}"
AUTO_MERGE_URL="${API_URL_PR}/auto_merge"
AUTH_HDR=(-H "Authorization: Bearer ${GITHUB_TOKEN}")
ACCEPT_HDR=(-H "Accept: application/vnd.github+json")

echo "INFO: Running local tests..."

# Determine package manager
PKG_MANAGER="npm"
if [[ -f yarn.lock ]]; then
  PKG_MANAGER="yarn"
fi

# Install dependencies if node_modules missing (optional)
if [[ ! -d node_modules ]]; then
  echo "node_modules not found — installing deps with ${PKG_MANAGER}..."
  if [[ "$PKG_MANAGER" == "yarn" ]]; then
    yarn install --frozen-lockfile || yarn install
  else
    npm ci || npm install
  fi
fi

# Run tests
echo "Running tests with ${PKG_MANAGER}..."
if [[ "$PKG_MANAGER" == "yarn" ]]; then
  if ! yarn test; then
    echo "ERROR: tests failed. Fix tests and re-run. Exiting."
    exit 2
  fi
else
  if ! npm test; then
    echo "ERROR: tests failed. Fix tests and re-run. Exiting."
    exit 2
  fi
fi

echo "Local tests passed."

# Optionally run prisma generate / migrate dev
if [[ "$RUN_MIGRATE_FLAG" == "--run-migrate" || "$RUN_MIGRATE_FLAG" == "-m" ]]; then
  if command -v npx >/dev/null 2>&1; then
    echo "Running npx prisma generate..."
    npx prisma generate
    echo "Running npx prisma migrate dev --name add_microsoft_integration ..."
    # This will prompt. If you want non-interactive, set environment appropriately.
    npx prisma migrate dev --name add_microsoft_integration
  else
    echo "Warning: npx not found; skipping prisma steps."
  fi
fi

# Enable auto-merge via REST endpoint
echo "Attempting to enable auto-merge (squash) for PR #${PR_NUMBER}..."
payload='{"merge_method":"squash"}'
RESP=$(curl -sS -X PUT "${AUTH_HDR[@]}" "${ACCEPT_HDR[@]}" "${AUTO_MERGE_URL}" -d "$payload" -w "\n%{http_code}")
HTTP_STATUS=$(echo "$RESP" | tail -n1)
HTTP_BODY=$(echo "$RESP" | sed '$d')

echo "HTTP_STATUS: $HTTP_STATUS"
if [[ -n "$HTTP_BODY" ]]; then
  if command -v jq >/dev/null 2>&1; then
    echo "$HTTP_BODY" | jq '.' || echo "$HTTP_BODY"
  else
    echo "$HTTP_BODY"
  fi
fi

if [[ "$HTTP_STATUS" =~ ^2 ]]; then
  echo "Auto-merge enable request succeeded (HTTP $HTTP_STATUS)."
else
  echo "Failed to enable auto-merge (HTTP $HTTP_STATUS)."
  echo "If 403/404/422: check token permissions, repo settings, and PR mergeable state."
  echo "Run the PR diagnostic command shown in the script comments if you need help."
  exit 3
fi

# Poll PR status until merged or timeout
echo "Polling PR status until merged (timeout 1 hour)..."
TIMEOUT_SECS=$((60*60))
INTERVAL=15
elapsed=0

while (( elapsed < TIMEOUT_SECS )); do
  PR_JSON=$(curl -sS "${AUTH_HDR[@]}" "${ACCEPT_HDR[@]}" "${API_URL_PR}")
  merged=$(echo "$PR_JSON" | jq -r '.merged // false')
  merged_by=$(echo "$PR_JSON" | jq -r '.merged_by.login // empty')
  mergeable_state=$(echo "$PR_JSON" | jq -r '.mergeable_state // empty')
  auto_merge=$(echo "$PR_JSON" | jq -r '.auto_merge // null')

  echo "Status @ $(date -u +%FT%TZ): merged=$merged, mergeable_state=$mergeable_state, auto_merge=$(echo "$auto_merge" | jq -c '.')"

  if [[ "$merged" == "true" ]]; then
    echo "PR #${PR_NUMBER} merged by ${merged_by:-(unknown)}."
    exit 0
  fi

  # If mergeable_state shows problems, print hint
  if [[ "$mergeable_state" == "dirty" || "$mergeable_state" == "blocked" ]]; then
    echo "Warning: mergeable_state is '$mergeable_state'. Branch may need updating or checks are failing."
    # We continue to wait because auto-merge may still succeed if checks were pending.
  fi

  sleep $INTERVAL
  elapsed=$((elapsed + INTERVAL))
done

echo "Timeout waiting for PR to be merged after $((TIMEOUT_SECS/60)) minutes."
echo "Check PR status manually: ${API_URL_PR}"
exit 4
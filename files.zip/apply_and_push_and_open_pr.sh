#!/usr/bin/env bash
# apply_and_push_and_open_pr.sh
#
# Apply the Microsoft Pay scaffold zip into the current git repo, create branch
# feature/microsoft-pay, run prisma migration (dev), run tests, commit, push,
# and optionally create a draft PR (or mark ready and enable auto-merge if requested).
#
# Usage:
#   ./apply_and_push_and_open_pr.sh /path/to/microsoft-pay-scaffold.zip YOUR_GITHUB_USERNAME [--ready-to-merge]
#
# Arguments:
#   1) Path to microsoft-pay-scaffold.zip (required)
#   2) Your GitHub username (required; used for PR head ref when using gh)
#   3) --ready-to-merge (optional): after creating the PR as draft, mark it Ready and
#      enable auto-merge (squash) if your account has permissions.
#
# Notes / safety:
# - Run from repository root (Space-LEAF-Corp/platform) and on a clean working tree.
# - Script uses git, unzip, rsync, npm/yarn, npx, and gh (optional) if present.
# - You will be prompted by prisma migrate dev for DB confirmations unless you pass flags.
# - Review files before committing. This script will commit changes automatically.
# - It will not attempt to merge the PR (only enables auto-merge if requested and permitted).
#
set -euo pipefail

ZIP_PATH="${1:-}"
GITHUB_USER="${2:-}"
READY_FLAG="${3:-}"

if [[ -z "$ZIP_PATH" || -z "$GITHUB_USER" ]]; then
  cat <<EOF
Usage: $0 /path/to/microsoft-pay-scaffold.zip YOUR_GITHUB_USERNAME [--ready-to-merge]

Example:
  $0 ~/Downloads/microsoft-pay-scaffold.zip GuardianNinja --ready-to-merge
EOF
  exit 1
fi

if [[ ! -f "$ZIP_PATH" ]]; then
  echo "ERROR: Zip file not found at: $ZIP_PATH"
  exit 1
fi

# Ensure we're in a git repo
if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "ERROR: Not inside a git repository. Run this from your repo root."
  exit 1
fi

# Ensure working tree is clean
if [[ -n "$(git status --porcelain)" ]]; then
  echo "ERROR: Working tree not clean. Please commit or stash changes first."
  git status --porcelain
  exit 1
fi

BRANCH="feature/microsoft-pay"
TMPDIR="$(mktemp -d)"
PR_BODY_FILE="pr_description.md"
PR_TITLE="feat(payments): add Microsoft Pay integration"

echo "Creating branch $BRANCH from origin/main..."
git fetch origin
# Create branch based on origin/main (safe even if local main differs)
git checkout -b "$BRANCH" origin/main

echo "Unpacking scaffold zip to temporary directory: $TMPDIR"
unzip -q "$ZIP_PATH" -d "$TMPDIR"

echo "Previewing files to be copied (dry-run):"
rsync -av --dry-run --exclude='.git' "$TMPDIR"/ . || true

read -p "Proceed to copy the scaffold files into the repo? (y/N): " PROCEED
PROCEED="${PROCEED:-N}"
if [[ "$PROCEED" != "y" && "$PROCEED" != "Y" ]]; then
  echo "Aborting — no files were copied. Cleaned up temp dir."
  rm -rf "$TMPDIR"
  exit 0
fi

echo "Copying files into repo..."
rsync -av --exclude='.git' "$TMPDIR"/ .

# If package manager detection: prefer yarn if yarn.lock exists, otherwise npm
PKG_MANAGER="npm"
if [[ -f yarn.lock ]]; then
  PKG_MANAGER="yarn"
fi

echo "Installing dependencies ($PKG_MANAGER)..."
if [[ "$PKG_MANAGER" == "yarn" ]]; then
  yarn install --frozen-lockfile || yarn install
else
  npm ci || npm install
fi

echo "Generating Prisma client..."
if command -v npx >/dev/null 2>&1; then
  npx prisma generate
else
  echo "WARNING: npx not found. Skipping prisma generate. Install Node.js/npm to run prisma commands."
fi

echo
echo "About to run 'npx prisma migrate dev --name add_microsoft_integration'."
echo "This may prompt you to create a shadow DB or confirm applying migrations."
read -p "Do you want to run prisma migrate dev now? (y/N): " RUN_MIGRATE
RUN_MIGRATE="${RUN_MIGRATE:-N}"
if [[ "$RUN_MIGRATE" == "y" || "$RUN_MIGRATE" == "Y" ]]; then
  if command -v npx >/dev/null 2>&1; then
    npx prisma migrate dev --name add_microsoft_integration
  else
    echo "ERROR: npx not found. Cannot run prisma migrate dev."
  fi
else
  echo "Skipping local prisma migrate dev. (You can run: npx prisma migrate dev --name add_microsoft_integration)"
fi

echo "Running tests..."
if [[ "$PKG_MANAGER" == "yarn" ]]; then
  if ! yarn test; then
    echo "Tests failed. Abort push. Fix tests and re-run script."
    exit 1
  fi
else
  if ! npm test; then
    echo "Tests failed. Abort push. Fix tests and re-run script."
    exit 1
  fi
fi

echo "Staging changes and committing..."
git add .
git commit -m "feat(integrations): add Microsoft Pay scaffold and migration" || {
  echo "No changes to commit or commit failed."
}

echo "Pushing branch to origin..."
git push --set-upstream origin "$BRANCH"

# Create PR with gh if available and authenticated
if command -v gh >/dev/null 2>&1; then
  if [[ -f "$PR_BODY_FILE" ]]; then
    echo "Creating draft PR with gh..."
    # Create PR as draft
    PR_CREATE_OUTPUT=$(gh pr create --base main --head "${GITHUB_USER}:${BRANCH}" --title "$PR_TITLE" --body-file "$PR_BODY_FILE" --draft 2>&1) || {
      echo "gh pr create failed:"
      echo "$PR_CREATE_OUTPUT"
      echo "You can create the PR manually in the web UI."
      exit 0
    }
    echo "$PR_CREATE_OUTPUT"
    # Obtain PR number
    PR_NUMBER=$(gh pr view --json number --jq .number) || PR_NUMBER=""
    echo "Created draft PR #: $PR_NUMBER"
  else
    echo "PR description file ($PR_BODY_FILE) not found. Creating draft PR without body."
    gh pr create --base main --head "${GITHUB_USER}:${BRANCH}" --title "$PR_TITLE" --draft || {
      echo "gh pr create failed. Please open PR manually."
      exit 0
    }
    PR_NUMBER=$(gh pr view --json number --jq .number) || PR_NUMBER=""
  fi
else
  echo "gh CLI not found. Branch pushed to origin. Create a draft PR in the GitHub UI from your fork/branch."
  PR_NUMBER=""
fi

# If user asked to ready the PR and enable auto-merge
if [[ "${READY_FLAG:-}" == "--ready-to-merge" ]]; then
  if [[ -z "$PR_NUMBER" ]]; then
    echo "Can't mark PR ready / enable auto-merge because PR number is unknown (gh missing or failed)."
  else
    echo "Marking PR #$PR_NUMBER ready for review..."
    gh pr ready "$PR_NUMBER" || echo "gh pr ready failed; you may need to mark the PR ready manually."

    echo "Enabling auto-merge (squash) for PR #$PR_NUMBER..."
    # Try enabling auto-merge by requesting merge with --auto (this will schedule a merge when checks pass)
    if gh pr merge "$PR_NUMBER" --auto --merge-method squash --confirm 2>/dev/null; then
      echo "Auto-merge (squash) enabled for PR #$PR_NUMBER (if you have permission)."
    else
      echo "Could not enable auto-merge programmatically. Please enable auto-merge (squash) in the PR UI or via an account with sufficient permissions."
    fi
  fi
fi

echo
echo "Cleanup temp dir: $TMPDIR"
rm -rf "$TMPDIR"

echo "Done."
echo "Next steps:"
echo " - Open the PR in GitHub (or check the draft PR created)."
echo " - Ensure repo secrets (DATABASE_URL, any secret manager credentials) are configured for CI."
echo " - Replace secret-manager and RBAC stubs before deploying to production."
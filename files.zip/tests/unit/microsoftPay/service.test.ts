import { exchangeCodeForToken, createIntegration } from '../../../src/services/microsoftPay/service';
import prisma from '../../../src/lib/prismaClient';
import axios from 'axios';
import { getSecretByReference } from '../../../src/services/microsoftPay/secretManager';

jest.mock('../../../src/lib/prismaClient');
jest.mock('axios');
jest.mock('../../../src/services/microsoftPay/secretManager');

const mockedAxios = axios as jest.Mocked<typeof axios>;
const mockedPrisma = prisma as any;
const mockedSecret = getSecretByReference as jest.MockedFunction<typeof getSecretByReference>;

describe('MicrosoftPay service', () => {
  afterEach(() => jest.resetAllMocks());

  test('exchangeCodeForToken throws if integration missing', async () => {
    mockedPrisma.microsoftIntegration.findUnique.mockResolvedValue(null);
    await expect(exchangeCodeForToken('nonexistent', 'code', 'http://c')).rejects.toThrow('Integration not found');
  });

  test('exchangeCodeForToken calls token endpoint', async () => {
    mockedPrisma.microsoftIntegration.findUnique.mockResolvedValue({
      id: 'i1',
      clientId: 'cid',
      clientSecretRef: 'secret://c',
      webhookSecretRef: 'wref',
    });
    mockedSecret.mockResolvedValue('supersecret');
    mockedAxios.post.mockResolvedValue({ data: { access_token: 'at', refresh_token: 'rt' } });

    const resp = await exchangeCodeForToken('i1', 'AUTH_CODE', 'https://cb');
    expect(resp.access_token).toBe('at');
    expect(mockedAxios.post).toHaveBeenCalled();
  });
});
```javascript
// integration e2e test using supertest
// Note: this is a scaffold. You must import your express app and mount the routes in test setup.

const request = require('supertest');
// Ensure your src/app.ts exports the app as default:
const app = require('../../src/app').default;

describe('MicrosoftPay e2e', () => {
  test('onboard requires auth', async () => {
    const res = await request(app)
      .post('/integrations/microsoft/onboard')
      .send({ tenantId: 't1', clientId: 'cid', clientSecretRef: 'secret://c', webhookSecretRef: 'secret://w' });
    expect([401,403]).toContain(res.statusCode);
  });
});
```
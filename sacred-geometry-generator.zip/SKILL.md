---
name: sacred-geometry-generator
description: Generate sacred geometry shapes and mandalas. Use when users ask to create, draw, or generate images of sacred geometry including Flower of Life, Metatron's Cube, Sri Yantra, Vesica Piscis, Seed of Life, Platonic solids, hexagram, pentagram, mandalas, toroidal patterns, or any spiritual/meditative geometric art.
---

# Sacred Geometry Image Generator

Generate beautiful sacred geometry images using AI-powered image synthesis.

## Supported Sacred Geometry Shapes

- **Flower of Life** - Overlapping circles creating a hexagonal pattern
- **Metatron's Cube** - 13 circles connected by straight lines
- **Sri Yantra** - Nine interlocking triangles
- **Seed of Life** - Seven overlapping circles
- **Vesica Piscis** - Two overlapping circles
- **Hexagram** - Six-pointed star
- **Pentagram** - Five-pointed star
- **Mandalas** - Circular spiritual patterns
- **Toroidal Patterns** - Donut-shaped energy patterns
- **Platonic Solids** - Tetrahedron, Cube, Octahedron, Dodecahedron, Icosahedron
- **Sacred Spiral** - Golden ratio spirals
- ** merkaba** - Two interlocking tetrahedrons

## How to Generate

1. Identify the sacred geometry shape or concept from the user's request
2. Compose a detailed prompt describing the desired image
3. Use the `image_synthesize` tool with the prompt
4. Return the generated image

## Prompt Template

```
[Shape name] sacred geometry, [style], [colors], [background], high detail, symmetrical, meditative, spiritual art, [additional details]

Examples:
- "Flower of Life sacred geometry, sacred geometry pattern, golden lines on dark background, precise circles, meditative, spiritual art"
- "Metatron's Cube sacred geometry, glowing lines, violet and gold colors, cosmic background, geometric precision"
- "Sri Yantra meditation mandala, vibrant colors, sacred geometry, spiritual art, precise triangular patterns"
```

## Output Format

Save generated images to `/workspace/imgs/sacred_geometry/` directory with descriptive filenames.

## Best Practices

- Include "sacred geometry" in prompts for accurate results
- Specify color schemes (gold, violet, teal, white on black, etc.)
- Mention symmetry for precise geometric patterns
- Add "meditative" or "spiritual" for authentic sacred art feel
- Specify background (dark, light, cosmic, gradient) for contrast
